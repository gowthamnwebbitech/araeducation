@extends('frontend.layout.app')
@section('title', "CS ACS CA CMA  Institute Coimbatore ACCA USCMA CLAT Coaching center Tamilnadu - ARA Education" )
@section('description', "Coimbatore’s best Coaching Institute for CA CS ACS CSEET CMA ICWA academy  is ARA Education. Tamilnadu’s No1 Coaching Center for  ACCA USCMA CLAT training India" )
@section('keyword', "ca institute in Coimbatore ara education,best institute for ca
coaching ara education,Best ca coaching institute in Coimbatore tamilnadu ara education,Best chartered
accountant coaching in Coimbatore tamilnadu ara education,ca coaching institutecseet-clat ara education,CA
coaching institute in coimabtore ara education,Top institute for ca coaching classes in Coimbatore ara
education, Top CA coaching institute in Coimbatore tamilnadu ara education,Top ACA coaching
institutes in Coimbatore tamilnadu ara education,Top chartered accountant coaching institute in
tamilnadu coimbatore india ara education,ca coaching institute nearby,CA coaching institute in
Coimbatore tamilnadu ara education,ACA coaching institute in Coimbatore tamilnadu ara
education,Chartered Accountant institute in Coimbatore tamilnadu ara education,cs institute in Coimbatore ara education,best institute for cs
coaching ara education,Best cs coaching institute in Coimbatore tamilnadu ara education,Best company
secretary coaching in Coimbatore tamilnadu ara education,cs coaching institute ara education,CS
coaching institute in coimabtore ara education,Top institute for cs coaching classes in Coimbatore ara
education, Top CS coaching institutes in Coimbatore tamilnadu ara education,Top ACS coaching
institutes in Coimbatore tamilnadu ara education,Top company secretary coaching institute in tamilnadu
coimbatore india ara education,cs coaching institute nearby,CS coaching institute in Coimbatore
tamilnadu ara education,ACS coaching institute in Coimbatore tamilnadu ara education,Company
secretary institute in Coimbatore tamilnadu ara education,Company secretary institute ara
education,top cseet coaching institute in tamilnadu india ara education,cma institute in Coimbatore ara education,best institute for cma-
icwa coaching ara education,Best cma-icwa coaching institute in Coimbatore tamilnadu ara
education,Best cost and management accountant coaching in Coimbatore tamilnadu ara education,cma
coaching institute ara education,Cma-ICWA coaching institute in coimabtore ara education,Top institute
for cma-icwa coaching classes in Coimbatore ara education, Top CMA coaching institute in Coimbatore
tamilnadu ara education,Top ACMA coaching institutes in Coimbatore tamilnadu ara education,Top cost
and management accountant coaching institute in tamilnadu coimbatore india ara education,cma
coaching institute nearby,CMA coaching institute in Coimbatore tamilnadu ara education,ACMA
coaching institute in Coimbatore tamilnadu ara education,Cost and Management Accountant institute in
Coimbatore tamilnadu ara education,Cost and Management Accountant institute ara education,top
CMA foundation coaching institute in tamilnadu india ara education,CMA foundation Coaching institute
in Coimbatore ara education,top CMA Foundation coaching institute in tamilnadu india ara
education,CMA Foundation Coaching institute in Coimbatore ara education,ACCA coaching in center in coimbatore ara
education,ACCA Coaching classes in coimbatore ara education Tamilnadu India,ACCA
Coaching Institute in coimbatore Tamilnadu,ACCA Skill Coaching classes in coimbatore,Acca
knowledge level Coaching in coimbatore Tamilnadu,ACCA Professional Coaching Classes in
Coimbatore, Online ACCA Coaching Classes in coimbatore,online ACCA Knowledge coaching
classes in coimbatore, ACCA F1 coaching classes in coimbatore tamilnadu India,ACCA F2
coaching classes in coimbatore tamilnadu,ACCA F3 Coaching Classes in coimbatore Tamilnadu
india,ACCA F4 Coaching classes in coimbatore Tamilnadu India,ACCA F5 Coaching classes in
coimbatore,ACCA F6 Coaching classes in coimbatore,ACCA F7 coaching classes in coimbatore
Tamilnadu,ACCA F8 Coaching classes in coimbatore,ACCA F9 coaching Classes in
coimbatore,ACCA P1 coaching classes in coimbatore Tamilnadu,ACCA P2 coaching classes in
coimbatore,ACCA P3 Caoching classes in coimbatore Tamilnadu India, Acca P4 Coaching
Classes in coimbatore, ACCA P5 Coaching calsses in coimbatore tamilandu ARA Education,
Acca P6 Coaching Classes in coimabtore ara education. Acca tutions coimbatore ara education,
Acca Training online, Acca training coimbatore Ara Education ,US CMA coaching in center in coimbatore ara education, CMA USA
Coaching classes in coimbatore ara education Tamilnadu India, USCMA Online Coaching Institute in
coimbatore Tamilnadu ara education,USCMA Part-1 Coaching classes in coimbatore ara education,
USCMA Part -11 Coaching in coimbatore ara educationTamilnadu,CMA USA Coaching Classes in
Coimbatore ara education, Online cma usa Coaching Classes in coimbatore ara education
tamilnadu,online USCMA training in ara education coimbatore tamilnadu India, US CMA coaching classes
near me in coimbatore tamilnadu India,CMA USA coaching classes near me, IMA USCMA Coaching
Classes in coimbatore Tamilnadu india, US CMA Coaching Academy in coimbatore Tamilnadu ara
education India, USCMA Institute in coimbatore ara education,CMA US Institute Coaching classes in
coimbatore,Online IMA USCMA coaching classes in coimbatore Tamilnadu ara education,ARA Education
USCMA coaching Coaching classes in coimbatore,what after 12th, USCMA after 12th, USCMA near me
coaching classes in coimbatore Tamilnadu,online cma us coaching classes in coimbatore ARA Education,
uscma India Coaching classes in coimbatore Tamilnadu India ,IFRS coaching in center in coimbatore ara education, IFRS-
International certification course in coimbatore ara education Tamilnadu India, IFRS Online Coaching
Institute in coimbatore Tamilnadu ara education,CERT IFRS Coaching classes in coimbatore ara
education,DIP IFRS Coaching in coimbatore ara educationTamilnadu,IFRS coaching Classes in Coimbatore
ara education, Online IFRS Coaching Classes in coimbatore ara education tamilnadu,online IFRS training
in ara education coimbatore tamilnadu India, IFRS coaching classes near me in coimbatore tamilnadu
India, DIP IFRS coaching classes near me, ACCA IFRS- Coaching Classes in coimbatore Tamilnadu india,
IFRS Coaching Academy ara education in coimbatore Tamilnadu ara education India, IFRS Institute in
coimbatore ara education, IFRS UK Institute Coaching classes in coimbatore" )
@section('content')

<section class="page-banner">
    <div class="banner-content">
        <div class="container">
            
            <div class="row gy-4 align-items-center">
                <div class="col-lg-6">
                <span class="banner-title">Campus Job Placement</span>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Campus Job Placement</li>
                </ol>
            </nav>
                </div>
                <div class="col-lg-6">
                    <div class="img-box">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/page-banner-img1.webp" alt="Online CFA Coaching">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="campus-detail">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h5 class="campus-subtitle">Campus Job Placement</h5>
                <h5 class="campus-title">Ara Education's Campus Job Placement</h5>
                <p class="campus-text">At Ara Education, We are proud of the dynamic and motivated students who
                    are mentored and supported to take on the
                    challenges and opportunities that await them in the Industry inside our campus. Ara education
                    assist all Indian
                    professional courses students ie CS | CMA-ICWA | CA and all International Professional Courses
                    ie
                    ACCA | US
                    CMA | IFRS | FRM | CPA | CFA to get trainingship and also job placement in India &
                    International. On
                    Monthly Basis On campus
                    interviews of big fortune companies will be organised by Ara education for supporting the
                    students.</p>
                <p class="campus-text">At Ara Education plays a crucial role in locating job opportunities for
                    passing out students from the institute by
                    keeping in touch with reputed firms and industrial establishments. Ara Education operates round
                    the year to facilitate
                    contacts between companies and professionals. The number of students placed through the campus
                    interviews is
                    continuously rising. On invitation, many reputed industries visit the institute to conduct
                    interviews.</p>
                <p class="campus-text">At Ara Education, We have been successful in maintaining our high
                    placement statistics over the years and the fact that
                    our students bear the recession blues with record breaking placements itself is a testimony to
                    our quality. Our
                    ingenious alumnae have set new standards in the corporate world through their estimable
                    contributions and it is my firm
                    conviction that we will continue that legacy in the years to come.</p>
                <p class="campus-text">At Ara Education organizes career guidance programmes for all the students
                    starting from first year. The cell arranges
                    training programmes like Mock Interviews, Group Discussions, Communication Skills Workshop etc
                    and it also organizes
                    Public Sector Exam Training for students who are interested to join Government Sectors. It also
                    invites HR Managers from
                    different industries to conduct training programmes for final year students.</p>
            </div>
            <div class="col-lg-12">
                <div class="row mt-4 g-3">
                    <div class="col-md-4">
                        <div class="img-box">
                            <a href="<?php echo url(''); ?>/public/frontend/assets/images/campus-1.png" data-fancyBox="gallery"><img
                                    src="<?php echo url(''); ?>/public/frontend/assets/images/campus-1.png" alt="Online Tuition in India"></a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="img-box">
                            <a href="<?php echo url(''); ?>/public/frontend/assets/images/campus-2.png" data-fancyBox="gallery"><img
                                    src="<?php echo url(''); ?>/public/frontend/assets/images/campus-2.png" alt="Online Tuition in Canada"></a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="img-box">
                            <a href="<?php echo url(''); ?>/public/frontend/assets/images/campus-3.png" data-fancyBox="gallery"><img
                                    src="<?php echo url(''); ?>/public/frontend/assets/images/campus-3.png" alt="Online Tuition in Bahrain"></a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="img-box">
                            <a href="<?php echo url(''); ?>/public/frontend/assets/images/campus-4.png" data-fancyBox="gallery"><img
                                    src="<?php echo url(''); ?>/public/frontend/assets/images/campus-4.png" alt="Online Tuition in Saudi Arabia"></a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="img-box">
                            <a href="<?php echo url(''); ?>/public/frontend/assets/images/campus-5.png" data-fancyBox="gallery"><img
                                    src="<?php echo url(''); ?>/public/frontend/assets/images/campus-5.png" alt="Online Tuition in Hong Kong"></a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="img-box">
                            <a href="<?php echo url(''); ?>/public/frontend/assets/images/campus-6.png" data-fancyBox="gallery"><img
                                    src="<?php echo url(''); ?>/public/frontend/assets/images/campus-6.png" alt="Online Tuition in Maldives"></a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="img-box">
                            <a href="<?php echo url(''); ?>/public/frontend/assets/images/campus-7.webp" data-fancyBox="gallery"><img
                                    src="<?php echo url(''); ?>/public/frontend/assets/images/campus-7.webp" alt="Online Tuition in USA"></a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="img-box">
                            <a href="<?php echo url(''); ?>/public/frontend/assets/images/campus-8.webp" data-fancyBox="gallery"><img
                                    src="<?php echo url(''); ?>/public/frontend/assets/images/campus-8.webp" alt="Online Tuition in Qatar"></a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="img-box">
                            <a href="<?php echo url(''); ?>/public/frontend/assets/images/campus-9.webp" data-fancyBox="gallery"><img
                                    src="<?php echo url(''); ?>/public/frontend/assets/images/campus-9.webp" alt="Online Tuition in Australia"></a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="img-box">
                            <a href="<?php echo url(''); ?>/public/frontend/assets/images/campus-10.webp" data-fancyBox="gallery"><img
                                    src="<?php echo url(''); ?>/public/frontend/assets/images/campus-10.webp" alt="Online Tuition in Oman"></a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="img-box">
                            <a href="<?php echo url(''); ?>/public/frontend/assets/images/campus-11.webp" data-fancyBox="gallery"><img
                                    src="<?php echo url(''); ?>/public/frontend/assets/images/campus-11.webp" alt="Online Tuition in Malaysia"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="placement-inner-detail">
    <div class="container">
        <h5 class="placement-title wow fadeInUp" data-wow-delay="0.2s"> 100% Placement
            Assistance Program</h5>
        <p class="placement-text wow fadeInUp" data-wow-delay="0.3s">Your success, Our Commitment, Guaranteed
            Interview assistance with Big Companies.</p>
        <div class="row gy-4 mt-4">
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-1.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-2.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-3.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-4.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-5.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-6.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-7.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-8.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-9.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-10.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-11.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-12.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-13.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-14.webp" alt="Ara Education 100% Placement in india " />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-15.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>

            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-16.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-17.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-18.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-19.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-20.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-21.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-22.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-23.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-24.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-26.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-27.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-28.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-29.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-30.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-31.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            <div class="col-lg-2 col-md-3">
                <a href="javascript:void(0)">
                    <div class="team-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/company/company-32.webp" alt="Ara Education 100% Placement in india" />
                    </div>
                </a>
            </div>
            </ul>
        </div>

</section>


@include('frontend.newsletter')

@endsection