@extends('frontend.layout.app')
@section('title', "CS ACS CA CMA  Institute Coimbatore ACCA USCMA CLAT Coaching center Tamilnadu - ARA Education" )
@section('description', "Coimbatore’s best Coaching Institute for CA CS ACS CSEET CMA ICWA academy  is ARA Education. Tamilnadu’s No1 Coaching Center for  ACCA USCMA CLAT training India" )
@section('keyword', "ca institute in Coimbatore ara education,best institute for ca
coaching ara education,Best ca coaching institute in Coimbatore tamilnadu ara education,Best chartered
accountant coaching in Coimbatore tamilnadu ara education,ca coaching institutecseet-clat ara education,CA
coaching institute in coimabtore ara education,Top institute for ca coaching classes in Coimbatore ara
education, Top CA coaching institute in Coimbatore tamilnadu ara education,Top ACA coaching
institutes in Coimbatore tamilnadu ara education,Top chartered accountant coaching institute in
tamilnadu coimbatore india ara education,ca coaching institute nearby,CA coaching institute in
Coimbatore tamilnadu ara education,ACA coaching institute in Coimbatore tamilnadu ara
education,Chartered Accountant institute in Coimbatore tamilnadu ara education,cs institute in Coimbatore ara education,best institute for cs
coaching ara education,Best cs coaching institute in Coimbatore tamilnadu ara education,Best company
secretary coaching in Coimbatore tamilnadu ara education,cs coaching institute ara education,CS
coaching institute in coimabtore ara education,Top institute for cs coaching classes in Coimbatore ara
education, Top CS coaching institutes in Coimbatore tamilnadu ara education,Top ACS coaching
institutes in Coimbatore tamilnadu ara education,Top company secretary coaching institute in tamilnadu
coimbatore india ara education,cs coaching institute nearby,CS coaching institute in Coimbatore
tamilnadu ara education,ACS coaching institute in Coimbatore tamilnadu ara education,Company
secretary institute in Coimbatore tamilnadu ara education,Company secretary institute ara
education,top cseet coaching institute in tamilnadu india ara education,cma institute in Coimbatore ara education,best institute for cma-
icwa coaching ara education,Best cma-icwa coaching institute in Coimbatore tamilnadu ara
education,Best cost and management accountant coaching in Coimbatore tamilnadu ara education,cma
coaching institute ara education,Cma-ICWA coaching institute in coimabtore ara education,Top institute
for cma-icwa coaching classes in Coimbatore ara education, Top CMA coaching institute in Coimbatore
tamilnadu ara education,Top ACMA coaching institutes in Coimbatore tamilnadu ara education,Top cost
and management accountant coaching institute in tamilnadu coimbatore india ara education,cma
coaching institute nearby,CMA coaching institute in Coimbatore tamilnadu ara education,ACMA
coaching institute in Coimbatore tamilnadu ara education,Cost and Management Accountant institute in
Coimbatore tamilnadu ara education,Cost and Management Accountant institute ara education,top
CMA foundation coaching institute in tamilnadu india ara education,CMA foundation Coaching institute
in Coimbatore ara education,top CMA Foundation coaching institute in tamilnadu india ara
education,CMA Foundation Coaching institute in Coimbatore ara education,ACCA coaching in center in coimbatore ara
education,ACCA Coaching classes in coimbatore ara education Tamilnadu India,ACCA
Coaching Institute in coimbatore Tamilnadu,ACCA Skill Coaching classes in coimbatore,Acca
knowledge level Coaching in coimbatore Tamilnadu,ACCA Professional Coaching Classes in
Coimbatore, Online ACCA Coaching Classes in coimbatore,online ACCA Knowledge coaching
classes in coimbatore, ACCA F1 coaching classes in coimbatore tamilnadu India,ACCA F2
coaching classes in coimbatore tamilnadu,ACCA F3 Coaching Classes in coimbatore Tamilnadu
india,ACCA F4 Coaching classes in coimbatore Tamilnadu India,ACCA F5 Coaching classes in
coimbatore,ACCA F6 Coaching classes in coimbatore,ACCA F7 coaching classes in coimbatore
Tamilnadu,ACCA F8 Coaching classes in coimbatore,ACCA F9 coaching Classes in
coimbatore,ACCA P1 coaching classes in coimbatore Tamilnadu,ACCA P2 coaching classes in
coimbatore,ACCA P3 Caoching classes in coimbatore Tamilnadu India, Acca P4 Coaching
Classes in coimbatore, ACCA P5 Coaching calsses in coimbatore tamilandu ARA Education,
Acca P6 Coaching Classes in coimabtore ara education. Acca tutions coimbatore ara education,
Acca Training online, Acca training coimbatore Ara Education ,US CMA coaching in center in coimbatore ara education, CMA USA
Coaching classes in coimbatore ara education Tamilnadu India, USCMA Online Coaching Institute in
coimbatore Tamilnadu ara education,USCMA Part-1 Coaching classes in coimbatore ara education,
USCMA Part -11 Coaching in coimbatore ara educationTamilnadu,CMA USA Coaching Classes in
Coimbatore ara education, Online cma usa Coaching Classes in coimbatore ara education
tamilnadu,online USCMA training in ara education coimbatore tamilnadu India, US CMA coaching classes
near me in coimbatore tamilnadu India,CMA USA coaching classes near me, IMA USCMA Coaching
Classes in coimbatore Tamilnadu india, US CMA Coaching Academy in coimbatore Tamilnadu ara
education India, USCMA Institute in coimbatore ara education,CMA US Institute Coaching classes in
coimbatore,Online IMA USCMA coaching classes in coimbatore Tamilnadu ara education,ARA Education
USCMA coaching Coaching classes in coimbatore,what after 12th, USCMA after 12th, USCMA near me
coaching classes in coimbatore Tamilnadu,online cma us coaching classes in coimbatore ARA Education,
uscma India Coaching classes in coimbatore Tamilnadu India ,IFRS coaching in center in coimbatore ara education, IFRS-
International certification course in coimbatore ara education Tamilnadu India, IFRS Online Coaching
Institute in coimbatore Tamilnadu ara education,CERT IFRS Coaching classes in coimbatore ara
education,DIP IFRS Coaching in coimbatore ara educationTamilnadu,IFRS coaching Classes in Coimbatore
ara education, Online IFRS Coaching Classes in coimbatore ara education tamilnadu,online IFRS training
in ara education coimbatore tamilnadu India, IFRS coaching classes near me in coimbatore tamilnadu
India, DIP IFRS coaching classes near me, ACCA IFRS- Coaching Classes in coimbatore Tamilnadu india,
IFRS Coaching Academy ara education in coimbatore Tamilnadu ara education India, IFRS Institute in
coimbatore ara education, IFRS UK Institute Coaching classes in coimbatore" )
@section('content')


<section class="page-banner">
    <div class="banner-content">
        <div class="container">
            <div class="row gy-4 align-items-center">
                <div class="col-lg-6">
                    <span class="banner-title">About Us</span>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">About Us</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-lg-6">
                    <div class="img-box">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/page-banner-img1.webp" alt="Ara Education Contact Detail">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="about-detail">
    <div class="container">
        <div class="row gy-4">
            <div class="col-lg-12">
                <h1 class="about-title">Best CA,  CS,  CMA, CLAT, JUDICIAL EXAMS, ACCA, EA, CMA-US, CFP,
                    CPA-US & AUS, CIMA, CFA, FRM, IFRS, CAMS
                    Coaching classes | Institute | Center | Academy in Coimbatore Tamilnadu, INDIA
                </h1>
            </div>
            <div class="col-lg-6">
                <div class="about-left">
                    <p class="about-text">Ara Education Provide Both Indian & International Professional Courses in
                        three Streams.
                    </p>
                    <ul class="about-list">
                        <li>In Common Stream line - After Completing 12th School (or) any degree they do
                            Professional Courses on fulltime (or)
                            part-time bases</li>
                        <li>In Integrated Stream line – The Student do only one course. But get Certification for
                            both Degree & Professional
                            Course.</li>
                        <li>In Parallel Stream line - The Student do Degree course separately and Professional
                            Course Separately at the same
                            period of time.</li>
                        <li>Indian Professional Courses – CA, CS, CMA,  CLAT, JUDICIAL EXAMS</li>
                        <li>International Professional Courses – ACCA, EA, CFP, CMA-US CPA-US & AUS, CIMA,
                            CFA,
                            FRM, IFRS, CAMS</li>
                        <li>Integrated Professional Courses – B.com|M.com (or) B.B.A|M.B. A with the above Indian
                            & International Courses.
                        </li>
                        <li>Law Courses – Law Entrance Coaching LLB 5 & LLB 3 Years , CLAT UG & PG , AIBE EXAM , JUDICIARY EXAM , Law College
                                            Subject Coaching , UGC NET- LAW EXAM
                                            Coaching
                                        
                        </li>
                        <li>Online Coaching Classes – We Provide Online Coaching India , Online Coaching Abroad
                                        
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="img-box">
                    <img src="<?php echo url(''); ?>/public/frontend/assets/images/new-img/img-11.webp" alt="Indian & International Professional">
                </div> 
            </div>
        </div>
    </div>
</section>


<section class="about-detail">
    <div class="container">
        <div class="row gy-4">
             <div class="col-lg-6 order-1 order-lg-0">
                <div class="img-box ">
                    <img src="<?php echo url(''); ?>/public/frontend/assets/images/new-img/img-12.webp" alt="Pioneer Institute in Coimbatore">
                </div> 
            </div>
            <div class="col-lg-6 order-0 order-lg-1">
                <div class="about-left">
                    <ul class="about-content-list">
                        <li><b>Ara Education</b> 1 st Pioneer Institute in Coimbatore,Tamilnadu India for CA (ICAI), CS (ACS),
                            CSEET
                            CMA (ICWA), CMA (USA), 
                            ACCA, EA, USCMA, CPA, CFA, CFP, CIMA, CPA AUS, TAXATION,CLAT LAW, CAMS,
                            ENTRANCE,& JUDICIAL EXAMS, providing
                            highest passing percentage with training and campus job placement with both Online &
                            Offline classes along with
                            integrated Custom made online Dual courses B.COM ., B.B.A ., MBA., MCOM with CS (ACS),
                            CMA (ICWA), CMA (USA), CA (ICAI),
                            ACCA, IFRS & CIMA.</li>
                        <li>
                            <b>Ara Education</b> is the exclusive full time professional college for
                            CA,CS,CMA,ACCA,USCMA,
                            with
                            BCOM, BBA, MCOM., MBA.., A
                            student of ARA EDUCATION as ARA’ians will be benefited with,One time fee Payment ,
                            Educational loan without interest, &
                            100% On campus Placement, Scholarship etc as all under one roof.
                        </li>
                        <li>
                            <b>Ara Education</b> have decent enough infrastructure to provide the classes. Our
                            campus is
                            centrally located at a posh area
                            in the city close to public transportation. Ara Education assists students for training
                            ship & also on campus interviews
                            of various big fortune companies on monthly basis. Ara Education provides Special and
                            individual attention to students
                            which is an added attraction.
                        </li>
                        <li><b>Ara Education</b> 1 st Pioneer Institute in Coimbatore, Tamilnadu provide
                            Registration,
                            Study Materials, Coaching, and
                            Training & Job Placements with one time fees collected till passing the enrolled subject
                            along with 0% interest EMI
                            Educational Loan.</li>
                    </ul>

                </div>
            </div>
           
        </div>
    </div>
</section>



<section class="about-detail">
    <div class="container">
        <div class="row gy-4">
           
            <div class="col-lg-6">
                <div class="about-left">
                    <ul class="about-content-list">
                        <li><b>Ara Education</b> Providing free coaching & up to 50% scholarship for the financially
                            poor
                            Children’s as per our policies
                            with work while study for their education monetary needs</li>
                        <li>
                            <b>Ara Education</b> 1 st Pioneer Institute in Coimbatore to join as partners with top
                            universities in India & Abroad to enrich
                            the need of customized | combined | Dual professional courses for the urge of
                            globalization.
                        </li>
                        <li>
                            <b>Ara Education</b>1 st Pioneer Institute in Coimbatore to introduce ACCA, CMA (USA),
                            CPA,
                            CFA, EA,CPA,CIMA, FRM, IFRS &
                            CFP,CPA AUS, Professional Courses with placement in India & Abroad with Visa assistance.
                            Highest Marks scored in
                            Southern region, more number of enrollment and passing percentage with large volume of
                            placement records.
                        </li>
                        <li><b>Ara Education</b> is an academy with undisputed leader when it comes to transforming
                            young
                            students into extraordinary
                            professionals which our nation needs. Ara Education an exclusive institute with world
                            class education of first choice to
                            secure high ranks in various professional courses. Ara Education is able to meet a
                            highly challenging set of performance
                            standards .It is a formal recognition of Ara Education’s Quality and success supporting
                            students throughout their
                            qualification.</li>
                    </ul>

                </div>
            </div>
 <div class="col-lg-6">
                <div class="img-box">
                    <img src="<?php echo url(''); ?>/public/frontend/assets/images/new-img/img-13.webp" alt="Providing free coaching">
                </div>

            </div>
        </div>
    </div>
</section>

<section class="about-detail">
    <div class="container">
        <div class="row gy-4">
            <div class="col-lg-6 order-1 order-lg-0">
                <div class="img-box">
                    <img src="<?php echo url(''); ?>/public/frontend/assets/images/new-img/img-14.webp" alt="consistently strives to mold efficient students">
                </div>

            </div>
            <div class="col-lg-6 order-0 order-lg-1">
                <div class="about-left">
                    <ul class="about-content-list">
                        <li><b>Ara Education</b> consistently strives to mold efficient students by consequently
                            improving
                            upon quality education has been
                            on its verge of providing excellence from its establishment in the year 2003. Ara
                            Education facilities which in turn
                            facilitates the students with requisite competence to meet any challenge in the global
                            corporate arena .Our past and
                            present academics results and social activities is the undisputable proof of our success
                            in the education industry. The
                            conceptual explanations are supported by contemporary problems picked up from
                            examinations held not only in India but
                            around the world. The question set not only covers the past papers but also the problems
                            which peep into the future.</li>
                        <li>
                            We <b>Ara Education</b> pride in having the best faculty with mix of professional
                            experience
                            and academicians with years of
                            industry experience and relevant teaching experience and 4 administrative staffs are
                            familiar with professional courses
                            who will guide students through all facets of the qualification to which we cater. We
                            Ara Education provide good library
                            facility, hostel facility and Wi-Fi enabled campus with air conditioned digital class
                            rooms
                        </li>

                    </ul>

                </div>
            </div>
            
        </div>
    </div>
</section>


<section class="achivement-detail">
    <div class="container">
        <div class="row gy-5 row-cols-lg-5 row-cols-md-2 row-cols-1 gx-0 gy-md-4 justify-content-between">
            <div class="col">
                <div class="box-content">
                    <div class="row gx-2 align-items-center">
                        <div class="col-3">
                            <div class="box-icon">
                                <img src="<?php echo url(''); ?>/public/frontend/assets/images/students.svg" alt="Ara Education Upskilled Students">
                            </div>
                        </div>
                        <div class="col-9">
                            <h5 class="box-title"><span class="count" data-count="35000">35000</span> +
                            </h5>
                            <p class="box-text">Upskilled Students</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="box-content">
                    <div class="row gx-2 align-items-center">
                        <div class="col-3">
                            <div class="box-icon">
                                <img src="<?php echo url(''); ?>/public/frontend/assets/images/trained-employees.svg" alt="Ara Education Trained Employees">
                            </div>
                        </div>
                        <div class="col-9">
                            <h5 class="box-title"><span class="count" data-count="10000">10000</span> +
                            </h5>
                            <p class="box-text">Trained Employees</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="box-content">
                    <div class="row gx-2 align-items-center">
                        <div class="col-3">
                            <div class="box-icon">
                                <img src="<?php echo url(''); ?>/public/frontend/assets/images/international.svg" alt="Best Coaching Center In All Over Country">
                            </div>
                        </div>
                        <div class="col-9">
                            <h5 class="box-title"><span class="count" data-count="45">45</span> +
                            </h5>
                            <p class="box-text"> Countries Covered</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="box-content">
                    <div class="row gx-2 align-items-center">
                        <div class="col-3">
                            <div class="box-icon">
                                <img src="<?php echo url(''); ?>/public/frontend/assets/images/hiring.svg" alt="Ara Education Hiring Partners">
                            </div>
                        </div>
                        <div class="col-9">
                            <h5 class="box-title"><span class="count" data-count="115">115</span> +</h5>
                            <p class="box-text">Hiring Partners</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="box-content">
                    <div class="row gx-2 align-items-center">
                        <div class="col-3">
                            <div class="box-icon">
                                <img src="<?php echo url(''); ?>/public/frontend/assets/images/percent.svg" alt="Online CA IPC Intermediate Coaching">
                            </div>
                        </div>
                        <div class=" col-9">
                            <h5 class="box-title"><span class="count" data-count="90">90</span> %</h5>
                            <p class="box-text">Pass Percentage</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
 


<section class="campus-job">
    <div class="container">
        <diiv class="row gy-4 align-items-center">
            <div class="col-lg-6 col-md-6">
                <h2 class="campus-title wow fadeInUp" data-wow-delay="0.2s">Campus Job Placement
                </h2>
                <p class="campus-text wow fadeInUp" data-wow-delay="0.4s">At Ara Education, We
                    are proud of the dynamic and motivated students who are
                    mentored and supported to take on the
                    challenges and opportunities that await them in the Industry inside our campus. Ara
                    Education assist all Indian
                    professional courses students ie CA  | CS | CMA-ICWA  and all International Professional Courses ie
                    ACCA | CIMA | IFRS | USCMA | CPA USA | EA | FRM | CFP | ACAMS | CPA AUS | Law Entrance Coaching  to get trainingship and also job placement in India & International. On
                    Monthly Basis On campus
                    interviews of big fortune companies will be organised by Ara Education for supporting.</p>
                <p class="mt-4 wow fadeInUp" data-wow-delay="0.4s"><a href="{{ route('campus_job_placement') }}"
                        class="btn common-btn">Learn More</a>
                </p>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="img-container">
                    <div class="img-box wow fadeInUp" data-wow-delay="0.5s">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/new-img/img-15.webp" alt="Campus Job Placement">
                    </div>
                </div>
            </div>
        </diiv>
    </div>
</section>


@include('frontend.newsletter')



@endsection