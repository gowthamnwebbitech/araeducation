@extends('frontend.layout.app')
@section('title', "CS ACS CA CMA  Institute Coimbatore ACCA USCMA CLAT Coaching center Tamilnadu - ARA Education" )
@section('description', "Coimbatore’s best Coaching Institute for CA CS ACS CSEET CMA ICWA academy  is ARA Education. Tamilnadu’s No1 Coaching Center for  ACCA USCMA CLAT training India" )
@section('keyword', "ca institute in Coimbatore ara education,best institute for ca
coaching ara education,Best ca coaching institute in Coimbatore tamilnadu ara education,Best chartered
accountant coaching in Coimbatore tamilnadu ara education,ca coaching institutecseet-clat ara education,CA
coaching institute in coimabtore ara education,Top institute for ca coaching classes in Coimbatore ara
education, Top CA coaching institute in Coimbatore tamilnadu ara education,Top ACA coaching
institutes in Coimbatore tamilnadu ara education,Top chartered accountant coaching institute in
tamilnadu coimbatore india ara education,ca coaching institute nearby,CA coaching institute in
Coimbatore tamilnadu ara education,ACA coaching institute in Coimbatore tamilnadu ara
education,Chartered Accountant institute in Coimbatore tamilnadu ara education,cs institute in Coimbatore ara education,best institute for cs
coaching ara education,Best cs coaching institute in Coimbatore tamilnadu ara education,Best company
secretary coaching in Coimbatore tamilnadu ara education,cs coaching institute ara education,CS
coaching institute in coimabtore ara education,Top institute for cs coaching classes in Coimbatore ara
education, Top CS coaching institutes in Coimbatore tamilnadu ara education,Top ACS coaching
institutes in Coimbatore tamilnadu ara education,Top company secretary coaching institute in tamilnadu
coimbatore india ara education,cs coaching institute nearby,CS coaching institute in Coimbatore
tamilnadu ara education,ACS coaching institute in Coimbatore tamilnadu ara education,Company
secretary institute in Coimbatore tamilnadu ara education,Company secretary institute ara
education,top cseet coaching institute in tamilnadu india ara education,cma institute in Coimbatore ara education,best institute for cma-
icwa coaching ara education,Best cma-icwa coaching institute in Coimbatore tamilnadu ara
education,Best cost and management accountant coaching in Coimbatore tamilnadu ara education,cma
coaching institute ara education,Cma-ICWA coaching institute in coimabtore ara education,Top institute
for cma-icwa coaching classes in Coimbatore ara education, Top CMA coaching institute in Coimbatore
tamilnadu ara education,Top ACMA coaching institutes in Coimbatore tamilnadu ara education,Top cost
and management accountant coaching institute in tamilnadu coimbatore india ara education,cma
coaching institute nearby,CMA coaching institute in Coimbatore tamilnadu ara education,ACMA
coaching institute in Coimbatore tamilnadu ara education,Cost and Management Accountant institute in
Coimbatore tamilnadu ara education,Cost and Management Accountant institute ara education,top
CMA foundation coaching institute in tamilnadu india ara education,CMA foundation Coaching institute
in Coimbatore ara education,top CMA Foundation coaching institute in tamilnadu india ara
education,CMA Foundation Coaching institute in Coimbatore ara education,ACCA coaching in center in coimbatore ara
education,ACCA Coaching classes in coimbatore ara education Tamilnadu India,ACCA
Coaching Institute in coimbatore Tamilnadu,ACCA Skill Coaching classes in coimbatore,Acca
knowledge level Coaching in coimbatore Tamilnadu,ACCA Professional Coaching Classes in
Coimbatore, Online ACCA Coaching Classes in coimbatore,online ACCA Knowledge coaching
classes in coimbatore, ACCA F1 coaching classes in coimbatore tamilnadu India,ACCA F2
coaching classes in coimbatore tamilnadu,ACCA F3 Coaching Classes in coimbatore Tamilnadu
india,ACCA F4 Coaching classes in coimbatore Tamilnadu India,ACCA F5 Coaching classes in
coimbatore,ACCA F6 Coaching classes in coimbatore,ACCA F7 coaching classes in coimbatore
Tamilnadu,ACCA F8 Coaching classes in coimbatore,ACCA F9 coaching Classes in
coimbatore,ACCA P1 coaching classes in coimbatore Tamilnadu,ACCA P2 coaching classes in
coimbatore,ACCA P3 Caoching classes in coimbatore Tamilnadu India, Acca P4 Coaching
Classes in coimbatore, ACCA P5 Coaching calsses in coimbatore tamilandu ARA Education,
Acca P6 Coaching Classes in coimabtore ara education. Acca tutions coimbatore ara education,
Acca Training online, Acca training coimbatore Ara Education ,US CMA coaching in center in coimbatore ara education, CMA USA
Coaching classes in coimbatore ara education Tamilnadu India, USCMA Online Coaching Institute in
coimbatore Tamilnadu ara education,USCMA Part-1 Coaching classes in coimbatore ara education,
USCMA Part -11 Coaching in coimbatore ara educationTamilnadu,CMA USA Coaching Classes in
Coimbatore ara education, Online cma usa Coaching Classes in coimbatore ara education
tamilnadu,online USCMA training in ara education coimbatore tamilnadu India, US CMA coaching classes
near me in coimbatore tamilnadu India,CMA USA coaching classes near me, IMA USCMA Coaching
Classes in coimbatore Tamilnadu india, US CMA Coaching Academy in coimbatore Tamilnadu ara
education India, USCMA Institute in coimbatore ara education,CMA US Institute Coaching classes in
coimbatore,Online IMA USCMA coaching classes in coimbatore Tamilnadu ara education,ARA Education
USCMA coaching Coaching classes in coimbatore,what after 12th, USCMA after 12th, USCMA near me
coaching classes in coimbatore Tamilnadu,online cma us coaching classes in coimbatore ARA Education,
uscma India Coaching classes in coimbatore Tamilnadu India ,IFRS coaching in center in coimbatore ara education, IFRS-
International certification course in coimbatore ara education Tamilnadu India, IFRS Online Coaching
Institute in coimbatore Tamilnadu ara education,CERT IFRS Coaching classes in coimbatore ara
education,DIP IFRS Coaching in coimbatore ara educationTamilnadu,IFRS coaching Classes in Coimbatore
ara education, Online IFRS Coaching Classes in coimbatore ara education tamilnadu,online IFRS training
in ara education coimbatore tamilnadu India, IFRS coaching classes near me in coimbatore tamilnadu
India, DIP IFRS coaching classes near me, ACCA IFRS- Coaching Classes in coimbatore Tamilnadu india,
IFRS Coaching Academy ara education in coimbatore Tamilnadu ara education India, IFRS Institute in
coimbatore ara education, IFRS UK Institute Coaching classes in coimbatore" )
@section('content')


<section class="page-banner">
    <div class="banner-content">
        <div class="container">
            <div class="row gy-4 align-items-center">
                <div class="col-lg-6">
                    <span class="banner-title">Elite Infrastructure</span>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Elite Infrastructure</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-lg-6">
                    <div class="img-box">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/page-banner-img1.webp" alt="Institute of Risk Management">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="infra-detail">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h5 class="infra-subtitle"><b>Elite Infrastructure </b></h5>
                <h5 class="main-title">State-of-the-Art Campus <img src="<?php echo url(''); ?>/public/frontend/assets/images/pointing-right.svg" alt="Elite Infrastructure" /> Facilities at Ara Education</h5>
                <p class="infra-text">At Ara Education, we take pride in our state-of-the-art campus, designed to
                    enhance the learning experience and ensure
                    academic success. Our facilities include fully air-conditioned classrooms with the latest
                    digital technologies, a
                    comprehensive library with resources for Indian and International Professional Courses, and a
                    Wi-Fi-enabled campus for
                    seamless online access. Our well-furnished hostels provide safe and comfortable living spaces
                    with separate wings for
                    boys and girls. Additionally, our modern computer labs, smart classrooms, and centralized camera
                    surveillance offer
                    students the tools, technology, and security they need to excel. At Ara Education, we believe
                    that a top-tier learning
                    environment is key to a well-rounded education.</p>

            </div>
        </div>
    </div>
    <div class="mt-5 " id="scroll-section">
        <!-- Horizontal Menu -->
        <div class="horizontal-menu-wrapper mb-4 sticky-header">
            <div class="arrow left-arrow">&#9664;</div>
            <div class="container">
                <div class="horizontal-menu">
                    <ul>
                        <!-- Add more menu items here -->
                        <li><a href="#section1" class="menu-item">Hostel For Boys | Girls</a></li>
                        <li><a href="#section2" class="menu-item">Library</a></li>
                        <li><a href="#section3" class="menu-item">WIFI Enabled Campus</a></li>
                        <li><a href="#section4" class="menu-item">Digital Classrooms</a></li>
                        <li><a href="#section5" class="menu-item">Computer Lab Facilities</a></li>
                        <li><a href="#section6" class="menu-item">Centralized Camera Surveillance</a></li>
                        <!-- ... -->
                    </ul>
                </div>
            </div>
            <div class="arrow right-arrow">&#9654;</div>
        </div>
        <!-- Sections -->
        <div id="section1" class="section-tab">
            <div class="row gx-0 align-items-center">
                <div class="col-md-6 order-1 order-md-0">
                    <div class="section-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/infra-inside-1.png" alt="Ara Eduaction's library collection">
                    </div>
                </div>
                <div class="col-md-6 order-0 order-md-1">
                    <div class="section-content">
                        <h5 class="section-title">Hostel For Boys | Girls </h5>
                        <p class="section-text">One of the key contributors to an intensive learning experience
                            is living in campus.Ara Education has a well-furnished
                            and aesthetically designed hostel with separate wings for boys and girls has been
                            constructed with a view to provide
                            best possible facilities to the students, Allotment of accommodation for the
                            students is on first-come, first-served
                            basis</p>
                        <h5 class="section-subtitle">FULLY AIR CONDITIONED CLASSROOM
                        </h5>
                        <p class="section-text">The Classrooms of Ara Education are fully air conditioned
                            classrooms provide a conducive and comfortable environment
                            where in the students are unperturbed by the changing weather conditions.</p>
                    </div>
                </div>
            </div>
        </div>
        <div id="section2" class="section-tab">
            <div class="row gx-0 align-items-center">

                <div class="col-md-6">
                    <div class="section-content">
                        <h5 class="section-title">Library Facilities </h5>
                        <p class="section-text">Ara Eduaction's library collection covers books on subjects such as
                            Indian & International Professional Courses. Library
                            is the source of our Success. Library is mainly committed to provide physical as well as
                            virtual access to books,
                            journals and other materials to the Students and Faculty</p>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="section-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/infra-inside-2.png" alt="Ara Eduaction's library collection">
                    </div>
                </div>
            </div>
        </div>
        <div id="section3" class="section-tab">
            <div class="row gx-0 align-items-center">
                <div class="col-md-6 order-1 order-md-0">
                    <div class="section-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/infra-inside-3.png" alt="Ara Eduaction's library collection">
                    </div>
                </div>
                <div class="col-md-6 order-0 order-md-1">
                    <div class="section-content">
                        <h5 class="section-title">WIFI Enabled Campus </h5>
                        <p class="section-text">Understanding the importance of internet in the field of
                            education. Ara Educations entire campus is enabled with Wi-Fi.
                            It allows students to access uninterrupted high internet connectivity anywhere in the
                            campus.</p>

                    </div>
                </div>

            </div>
        </div>
        <div id="section4" class="section-tab">
            <div class="row gx-0 align-items-center">

                <div class="col-md-6">
                    <div class="section-content">
                        <h5 class="section-title">Digital Classrooms</h5>
                        <p class="section-text">Ara Eduaction's classrooms are equipped with audio visual digital
                            facilities. .The classrooms of the institute are smart
                            in the true sense of the word. The classrooms are equipped with interactive smart boards
                            and projectors. We have
                            adequate computers and laptops where ever required.</p>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="section-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/infra-inside-4.png" alt="Smart board clasrooms in india">
                    </div>
                </div>
            </div>
        </div>
        <div id="section5" class="section-tab">
            <div class="row gx-0 align-items-center">
                <div class="col-md-6 order-1 order-md-0">
                    <div class="section-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/infra-inside-5.png" alt="Ara Education Computer Lab Facilities">
                    </div>
                </div>
                <div class="col-md-6 order-0 order-md-1">
                    <div class="section-content">
                        <h5 class="section-title">Computer Lab Facilities </h5>
                        <p class="section-text">Ara Education has Internet enable computer lab with over 12
                            computers to meet the student's Information Technology
                            needs. Trained and experienced teachers provide both theoretical and practical lessons
                            for students to help them
                            navigate a rapidly changing technology driven world towards the professional courses</p>
                        <p class="section-text">Ara Education's the classrooms are well designed both aesthetically
                            and functionally. They are equipped with power
                            saving LED lights which make the room appear bright . The furniture is both comfortable
                            and beautiful.</p>
                    </div>
                </div>

            </div>
        </div>
        <div id="section6" class="section-tab">
            <div class="row gx-0 align-items-center">

                <div class="col-md-6">
                    <div class="section-content">
                        <h5 class="section-title">Centralized Camera Surveillance</h5>
                        <p class="section-text">Ara Eduaction's classrooms are equipped with audio visual digital
                            facilities. .The classrooms of the institute are smart
                            in the true sense of the word. The classrooms are equipped with interactive smart boards
                            and projectors. We have
                            adequate computers and laptops where ever required.</p>

                    </div>
                </div>
                <div class="col-md-6">
                    <div class="section-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/infra-inside-6.png" alt="Centralized Camera Surveillance in Ara Education">
                    </div>
                </div>
            </div>
        </div>


    </div>
</section>


@include('frontend.newsletter')




@endsection