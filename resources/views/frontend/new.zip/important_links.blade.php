@extends('frontend.layout.app')
@section('title', "CS ACS CA CMA  Institute Coimbatore ACCA USCMA CLAT Coaching center Tamilnadu - ARA Education" )
@section('description', "Coimbatore’s best Coaching Institute for CA CS ACS CSEET CMA ICWA academy  is ARA Education. Tamilnadu’s No1 Coaching Center for  ACCA USCMA CLAT training India" )
@section('keyword', "ca institute in Coimbatore ara education,best institute for ca
coaching ara education,Best ca coaching institute in Coimbatore tamilnadu ara education,Best chartered
accountant coaching in Coimbatore tamilnadu ara education,ca coaching institutecseet-clat ara education,CA
coaching institute in coimabtore ara education,Top institute for ca coaching classes in Coimbatore ara
education, Top CA coaching institute in Coimbatore tamilnadu ara education,Top ACA coaching
institutes in Coimbatore tamilnadu ara education,Top chartered accountant coaching institute in
tamilnadu coimbatore india ara education,ca coaching institute nearby,CA coaching institute in
Coimbatore tamilnadu ara education,ACA coaching institute in Coimbatore tamilnadu ara
education,Chartered Accountant institute in Coimbatore tamilnadu ara education,cs institute in Coimbatore ara education,best institute for cs
coaching ara education,Best cs coaching institute in Coimbatore tamilnadu ara education,Best company
secretary coaching in Coimbatore tamilnadu ara education,cs coaching institute ara education,CS
coaching institute in coimabtore ara education,Top institute for cs coaching classes in Coimbatore ara
education, Top CS coaching institutes in Coimbatore tamilnadu ara education,Top ACS coaching
institutes in Coimbatore tamilnadu ara education,Top company secretary coaching institute in tamilnadu
coimbatore india ara education,cs coaching institute nearby,CS coaching institute in Coimbatore
tamilnadu ara education,ACS coaching institute in Coimbatore tamilnadu ara education,Company
secretary institute in Coimbatore tamilnadu ara education,Company secretary institute ara
education,top cseet coaching institute in tamilnadu india ara education,cma institute in Coimbatore ara education,best institute for cma-
icwa coaching ara education,Best cma-icwa coaching institute in Coimbatore tamilnadu ara
education,Best cost and management accountant coaching in Coimbatore tamilnadu ara education,cma
coaching institute ara education,Cma-ICWA coaching institute in coimabtore ara education,Top institute
for cma-icwa coaching classes in Coimbatore ara education, Top CMA coaching institute in Coimbatore
tamilnadu ara education,Top ACMA coaching institutes in Coimbatore tamilnadu ara education,Top cost
and management accountant coaching institute in tamilnadu coimbatore india ara education,cma
coaching institute nearby,CMA coaching institute in Coimbatore tamilnadu ara education,ACMA
coaching institute in Coimbatore tamilnadu ara education,Cost and Management Accountant institute in
Coimbatore tamilnadu ara education,Cost and Management Accountant institute ara education,top
CMA foundation coaching institute in tamilnadu india ara education,CMA foundation Coaching institute
in Coimbatore ara education,top CMA Foundation coaching institute in tamilnadu india ara
education,CMA Foundation Coaching institute in Coimbatore ara education,ACCA coaching in center in coimbatore ara
education,ACCA Coaching classes in coimbatore ara education Tamilnadu India,ACCA
Coaching Institute in coimbatore Tamilnadu,ACCA Skill Coaching classes in coimbatore,Acca
knowledge level Coaching in coimbatore Tamilnadu,ACCA Professional Coaching Classes in
Coimbatore, Online ACCA Coaching Classes in coimbatore,online ACCA Knowledge coaching
classes in coimbatore, ACCA F1 coaching classes in coimbatore tamilnadu India,ACCA F2
coaching classes in coimbatore tamilnadu,ACCA F3 Coaching Classes in coimbatore Tamilnadu
india,ACCA F4 Coaching classes in coimbatore Tamilnadu India,ACCA F5 Coaching classes in
coimbatore,ACCA F6 Coaching classes in coimbatore,ACCA F7 coaching classes in coimbatore
Tamilnadu,ACCA F8 Coaching classes in coimbatore,ACCA F9 coaching Classes in
coimbatore,ACCA P1 coaching classes in coimbatore Tamilnadu,ACCA P2 coaching classes in
coimbatore,ACCA P3 Caoching classes in coimbatore Tamilnadu India, Acca P4 Coaching
Classes in coimbatore, ACCA P5 Coaching calsses in coimbatore tamilandu ARA Education,
Acca P6 Coaching Classes in coimabtore ara education. Acca tutions coimbatore ara education,
Acca Training online, Acca training coimbatore Ara Education ,US CMA coaching in center in coimbatore ara education, CMA USA
Coaching classes in coimbatore ara education Tamilnadu India, USCMA Online Coaching Institute in
coimbatore Tamilnadu ara education,USCMA Part-1 Coaching classes in coimbatore ara education,
USCMA Part -11 Coaching in coimbatore ara educationTamilnadu,CMA USA Coaching Classes in
Coimbatore ara education, Online cma usa Coaching Classes in coimbatore ara education
tamilnadu,online USCMA training in ara education coimbatore tamilnadu India, US CMA coaching classes
near me in coimbatore tamilnadu India,CMA USA coaching classes near me, IMA USCMA Coaching
Classes in coimbatore Tamilnadu india, US CMA Coaching Academy in coimbatore Tamilnadu ara
education India, USCMA Institute in coimbatore ara education,CMA US Institute Coaching classes in
coimbatore,Online IMA USCMA coaching classes in coimbatore Tamilnadu ara education,ARA Education
USCMA coaching Coaching classes in coimbatore,what after 12th, USCMA after 12th, USCMA near me
coaching classes in coimbatore Tamilnadu,online cma us coaching classes in coimbatore ARA Education,
uscma India Coaching classes in coimbatore Tamilnadu India ,IFRS coaching in center in coimbatore ara education, IFRS-
International certification course in coimbatore ara education Tamilnadu India, IFRS Online Coaching
Institute in coimbatore Tamilnadu ara education,CERT IFRS Coaching classes in coimbatore ara
education,DIP IFRS Coaching in coimbatore ara educationTamilnadu,IFRS coaching Classes in Coimbatore
ara education, Online IFRS Coaching Classes in coimbatore ara education tamilnadu,online IFRS training
in ara education coimbatore tamilnadu India, IFRS coaching classes near me in coimbatore tamilnadu
India, DIP IFRS coaching classes near me, ACCA IFRS- Coaching Classes in coimbatore Tamilnadu india,
IFRS Coaching Academy ara education in coimbatore Tamilnadu ara education India, IFRS Institute in
coimbatore ara education, IFRS UK Institute Coaching classes in coimbatore" )
@section('content')



<section class="page-banner">
    <div class="banner-content">
        <div class="container">
            <div class="row gy-4 align-items-center">
                <div class="col-lg-6">
                    <span class="banner-title">Important Links</span>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Important Links</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-lg-6">
                    <div class="img-box">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/page-banner-img1.webp" alt="Global Association of Risk Professionals |GARP - [FRM]">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="important-links">
    <div class="container">
        <h5 class="import-subtitle">Links</h5>
        <h2 class="import-title">IMPORTANT LINKS</h2>
        <ul class="important-link-list">
            <li>
                <a href="https://www.icsi.edu/home/" class="link-box wow zoomIn" target="_blank"
                    data-wow-delay="0.2s">
                    <p class="link-text">Institute of Company Secretaries of India <b>[ICSI]</b></p>
                    <span class="text-link">https://www.icsi.edu/home/</span>
                </a>
            </li>
            <li>
                <a href="https://www.icai.org/" class="link-box wow zoomIn" target="_blank" data-wow-delay="0.2s">
                    <p class="link-text">Institute of Chartered Accountants of India <b>[ICAI]</b></p>
                    <span class="text-link">https://www.icai.org/</span>
                </a>
            </li>
            <li>
                <a href="https://icmai.in/icmai/" class="link-box wow zoomIn" target="_blank" data-wow-delay="0.2s">
                    <p class="link-text">Institute of Cost Accountants of India <b>[CMA]</b></p>
                    <span class="text-link">https://icmai.in/icmai/</span>
                </a>
            </li>
            <li>
                <a href="https://consortiumofnlus.ac.in/" class="link-box wow zoomIn" target="_blank"
                    data-wow-delay="0.2s">
                    <p class="link-text">The Common Law Admission Test <b>[CLAT]</b></p>
                    <span class="text-link">https://consortiumofnlus.ac.in/</span>
                </a>
            </li>
            <li>
                <a href="https://www.accaglobal.com/gb/en.html" class="link-box wow zoomIn" target="_blank"
                    data-wow-delay="0.2s">
                    <p class="link-text">Association of Chartered Certified Accountants <b>[ACCA]</b></p>
                    <span class="text-link">https://www.accaglobal.com/gb/en.html</span>
                </a>
            </li>
            <li>
                <a href="https://myfuture.cimaglobal.com/" class="link-box wow zoomIn" target="_blank"
                    data-wow-delay="0.2s">
                    <p class="link-text">The Chartered Institute of Management Accountants <b>[CIMA - UK]</b></p>
                    <span class="text-link">https://myfuture.cimaglobal.com/</span>
                </a>
            </li>
            <li>
                <a href="https://www.cfauk.org/" class="link-box wow zoomIn" target="_blank" data-wow-delay="0.2s">
                    <p class="link-text">Institute of Chartered Financial Analyst <b>[CFA - UK]</b></p>
                    <span class="text-link">https://www.cfauk.org/</span>
                </a>
            </li>
            <li>
                <a href="https://www.theirm.org/" class="link-box wow zoomIn" target="_blank" data-wow-delay="0.2s">
                    <p class="link-text">Institute of Risk Management <b>[IRM – UK]</b></p>
                    <span class="text-link">https://www.theirm.org/</span>
                </a>
            </li>
            <li>
                <a href="https://www.ifrs.org/" class="link-box wow zoomIn" target="_blank" data-wow-delay="0.2s">
                    <p class="link-text">International Financial Reporting Standards <b>[IFRS]</b></p>
                    <span class="text-link">https://www.ifrs.org/</span>
                </a>
            </li>
            <li>
                <a href="https://in.imanet.org/en/" class="link-box wow zoomIn" target="_blank"
                    data-wow-delay="0.2s">
                    <p class="link-text">Institute of Management Accountants <b>[CMA - USA]</b></p>
                    <span class="text-link">https://in.imanet.org/en/</span>
                </a>
            </li>
            <li>
                <a href="https://www.irs.gov/" class="link-box wow zoomIn" target="_blank" data-wow-delay="0.2s">
                    <p class="link-text">The Internal Revenue Service - Enrolled Agent <b>[EA - USA]</b></p>
                    <span class="text-link">https://www.irs.gov/</span>
                </a>
            </li>
            <li>
                <a href="https://www.aicpa-cima.com/home" class="link-box wow zoomIn" target="_blank"
                    data-wow-delay="0.2s">
                    <p class="link-text">Institute of Certified Public Accountant <b>[ CPA - USA]</b>

                    </p>
                    <span class="text-link">https://www.aicpa-cima.com/home</span>
                </a>
            </li>
            <li>
                <a href="https://www.garp.org/frm" class="link-box wow zoomIn" target="_blank"
                    data-wow-delay="0.2s">
                    <p class="link-text">Global Association of Risk Professionals |GARP - <b>[FRM]</b></p>
                    <span class="text-link">https://www.garp.org/frm</span>
                </a>
            </li>
            <li>
                <a href="https://www.cfp.net/" class="link-box wow zoomIn" target="_blank" data-wow-delay="0.2s">
                    <p class="link-text">Certified Financial Planner Board of Standards <b>[ CFP - USA]</b></p>
                    <span class="text-link">https://www.cfp.net/</span>
                </a>
            </li>
            <li>
                <a href="https://www.cpaaustralia.com.au/" class="link-box wow zoomIn" target="_blank"
                    data-wow-delay="0.2s">
                    <p class="link-text">Incorporated Institute of Accountants <b>[CPA – AUS]</b></p>
                    <span class="text-link">https://www.cpaaustralia.com.au/</span>
                </a>
            </li>
            <li>
                <a href=" https://cmaaustralia.edu.au/" class="link-box wow zoomIn" target="_blank"
                    data-wow-delay="0.2s">
                    <p class="link-text">Institute of Certified Management Accountants <b>[CMA – AUS]</b></p>
                    <span class="text-link"> https://cmaaustralia.edu.au/</span>
                </a>
            </li>
            <li>
                <a href="https://www.publicaccountants.org.au/about" class="link-box wow zoomIn" target="_blank"
                    data-wow-delay="0.2s">
                    <p class="link-text">Institute of Public Accountants <b>[ AT – AUS]</b></p>
                    <span class="text-link">https://www.publicaccountants.org.au/about</span>
                </a>
            </li>
            <li>
                <a href="https://www.acams.org/en" class="link-box wow zoomIn" target="_blank"
                    data-wow-delay="0.2s">
                    <p class="link-text">Certified Anti-Money Laundering Specialist <b>[CAMS]</b></p>
                    <span class="text-link">https://www.acams.org/en</span>
                </a>
            </li>
        </ul>
    </div>
</section>



@include('frontend.newsletter')


@endsection