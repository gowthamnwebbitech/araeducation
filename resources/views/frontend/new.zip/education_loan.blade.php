@extends('frontend.layout.app')
@section('title', "CS ACS CA CMA  Institute Coimbatore ACCA USCMA CLAT Coaching center Tamilnadu - ARA Education" )
@section('description', "Coimbatore’s best Coaching Institute for CA CS ACS CSEET CMA ICWA academy  is ARA Education. Tamilnadu’s No1 Coaching Center for  ACCA USCMA CLAT training India" )
@section('keyword', "ca institute in Coimbatore ara education,best institute for ca
coaching ara education,Best ca coaching institute in Coimbatore tamilnadu ara education,Best chartered
accountant coaching in Coimbatore tamilnadu ara education,ca coaching institutecseet-clat ara education,CA
coaching institute in coimabtore ara education,Top institute for ca coaching classes in Coimbatore ara
education, Top CA coaching institute in Coimbatore tamilnadu ara education,Top ACA coaching
institutes in Coimbatore tamilnadu ara education,Top chartered accountant coaching institute in
tamilnadu coimbatore india ara education,ca coaching institute nearby,CA coaching institute in
Coimbatore tamilnadu ara education,ACA coaching institute in Coimbatore tamilnadu ara
education,Chartered Accountant institute in Coimbatore tamilnadu ara education,cs institute in Coimbatore ara education,best institute for cs
coaching ara education,Best cs coaching institute in Coimbatore tamilnadu ara education,Best company
secretary coaching in Coimbatore tamilnadu ara education,cs coaching institute ara education,CS
coaching institute in coimabtore ara education,Top institute for cs coaching classes in Coimbatore ara
education, Top CS coaching institutes in Coimbatore tamilnadu ara education,Top ACS coaching
institutes in Coimbatore tamilnadu ara education,Top company secretary coaching institute in tamilnadu
coimbatore india ara education,cs coaching institute nearby,CS coaching institute in Coimbatore
tamilnadu ara education,ACS coaching institute in Coimbatore tamilnadu ara education,Company
secretary institute in Coimbatore tamilnadu ara education,Company secretary institute ara
education,top cseet coaching institute in tamilnadu india ara education,cma institute in Coimbatore ara education,best institute for cma-
icwa coaching ara education,Best cma-icwa coaching institute in Coimbatore tamilnadu ara
education,Best cost and management accountant coaching in Coimbatore tamilnadu ara education,cma
coaching institute ara education,Cma-ICWA coaching institute in coimabtore ara education,Top institute
for cma-icwa coaching classes in Coimbatore ara education, Top CMA coaching institute in Coimbatore
tamilnadu ara education,Top ACMA coaching institutes in Coimbatore tamilnadu ara education,Top cost
and management accountant coaching institute in tamilnadu coimbatore india ara education,cma
coaching institute nearby,CMA coaching institute in Coimbatore tamilnadu ara education,ACMA
coaching institute in Coimbatore tamilnadu ara education,Cost and Management Accountant institute in
Coimbatore tamilnadu ara education,Cost and Management Accountant institute ara education,top
CMA foundation coaching institute in tamilnadu india ara education,CMA foundation Coaching institute
in Coimbatore ara education,top CMA Foundation coaching institute in tamilnadu india ara
education,CMA Foundation Coaching institute in Coimbatore ara education,ACCA coaching in center in coimbatore ara
education,ACCA Coaching classes in coimbatore ara education Tamilnadu India,ACCA
Coaching Institute in coimbatore Tamilnadu,ACCA Skill Coaching classes in coimbatore,Acca
knowledge level Coaching in coimbatore Tamilnadu,ACCA Professional Coaching Classes in
Coimbatore, Online ACCA Coaching Classes in coimbatore,online ACCA Knowledge coaching
classes in coimbatore, ACCA F1 coaching classes in coimbatore tamilnadu India,ACCA F2
coaching classes in coimbatore tamilnadu,ACCA F3 Coaching Classes in coimbatore Tamilnadu
india,ACCA F4 Coaching classes in coimbatore Tamilnadu India,ACCA F5 Coaching classes in
coimbatore,ACCA F6 Coaching classes in coimbatore,ACCA F7 coaching classes in coimbatore
Tamilnadu,ACCA F8 Coaching classes in coimbatore,ACCA F9 coaching Classes in
coimbatore,ACCA P1 coaching classes in coimbatore Tamilnadu,ACCA P2 coaching classes in
coimbatore,ACCA P3 Caoching classes in coimbatore Tamilnadu India, Acca P4 Coaching
Classes in coimbatore, ACCA P5 Coaching calsses in coimbatore tamilandu ARA Education,
Acca P6 Coaching Classes in coimabtore ara education. Acca tutions coimbatore ara education,
Acca Training online, Acca training coimbatore Ara Education ,US CMA coaching in center in coimbatore ara education, CMA USA
Coaching classes in coimbatore ara education Tamilnadu India, USCMA Online Coaching Institute in
coimbatore Tamilnadu ara education,USCMA Part-1 Coaching classes in coimbatore ara education,
USCMA Part -11 Coaching in coimbatore ara educationTamilnadu,CMA USA Coaching Classes in
Coimbatore ara education, Online cma usa Coaching Classes in coimbatore ara education
tamilnadu,online USCMA training in ara education coimbatore tamilnadu India, US CMA coaching classes
near me in coimbatore tamilnadu India,CMA USA coaching classes near me, IMA USCMA Coaching
Classes in coimbatore Tamilnadu india, US CMA Coaching Academy in coimbatore Tamilnadu ara
education India, USCMA Institute in coimbatore ara education,CMA US Institute Coaching classes in
coimbatore,Online IMA USCMA coaching classes in coimbatore Tamilnadu ara education,ARA Education
USCMA coaching Coaching classes in coimbatore,what after 12th, USCMA after 12th, USCMA near me
coaching classes in coimbatore Tamilnadu,online cma us coaching classes in coimbatore ARA Education,
uscma India Coaching classes in coimbatore Tamilnadu India ,IFRS coaching in center in coimbatore ara education, IFRS-
International certification course in coimbatore ara education Tamilnadu India, IFRS Online Coaching
Institute in coimbatore Tamilnadu ara education,CERT IFRS Coaching classes in coimbatore ara
education,DIP IFRS Coaching in coimbatore ara educationTamilnadu,IFRS coaching Classes in Coimbatore
ara education, Online IFRS Coaching Classes in coimbatore ara education tamilnadu,online IFRS training
in ara education coimbatore tamilnadu India, IFRS coaching classes near me in coimbatore tamilnadu
India, DIP IFRS coaching classes near me, ACCA IFRS- Coaching Classes in coimbatore Tamilnadu india,
IFRS Coaching Academy ara education in coimbatore Tamilnadu ara education India, IFRS Institute in
coimbatore ara education, IFRS UK Institute Coaching classes in coimbatore" )
@section('content')

<style type="text/css">
    .combined-class {
        border-radius: 15px;
    }

    .list-sty li::after {
        content: "";
        position: absolute;
        left: 0px;
        top: 10px;
        width: 8px;
        height: 8px;
        border-radius: 0px;
        background: var(--red-color);
        transform: rotate(-45deg);

    }

    .list-sty li {
        font-size: 15px;
        color: #323232;
        margin-bottom: 15px;
        padding-left: 25px;
        text-align: justify;
        position: relative;
    }

    .padd-both-40 {
        padding: 40px 0px !important;
    }

    .clr-000 {
        color: #000 !important;
    }

    .clr-fff {
        color: #fff !important;
    }

    .marg-tp-10 {
        margin-top: 10px !important;
    }

    .marg-tp-20 {
        margin-top: 20px !important;
    }

    .marg-tp-30 {
        margin-top: 30px !important;
    }

    .marg-btm-10 {
        margin-bottom: 10px !important;
    }

    .marg-btm-20 {
        margin-bottom: 20px !important;
    }

    .marg-btm-30 {
        margin-bottom: 30px !important;
    }

    .fnt-we-500 {
        font-weight: 500 !important;
    }

    .fnt-we-600 {
        font-weight: 600 !important;
    }

    .fnt-16 {
        font-size: 16px;
    }

    .comm-para {
        font-size: 16px;
        line-height: 1.7;
        font-weight: 400;
    }

    .txt-jus {
        text-align: justify !important;
    }

    .clr-ed283b {
        color: #ed283b !important;
    }

    .fnt-25 {
        font-size: 25px !important;
    }

    .fnt-20 {
        font-size: 20px !important;
    }

    img {
        width: 100%;
    }

    .table-main {
        border-collapse: collapse;
        border-spacing: 0;
        width: 100%;
        border: 1px solid #ddd;

        /*overflow-x: auto;*/
    }

    .wrapper-table {
        overflow-x: auto;
    }

    .table-main th,
    .table-main td {
        text-align: center;
        padding: 12px;
    }

    .table-main th {
        background: #ee2737;
        border-right: 1px solid #ddd;
        color: #fff !important;
        font-size: 17px;
        font-weight: 600 !important;
    }

    .table-main tr:nth-child(even) {
        background-color: #f2f2f2
    }

    .table-main td {
        border-right: 1px solid #a9a3a3;
        font-size: 15px;
        font-weight: 500;
        color: #000;

    }

    .marg-btm-50 {
        margin-bottom: 50px !important;
    }

    .content-big {
        position: relative;
        background: #fff;
        box-shadow: 0 0 8px #00000047;
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 25px;
    }

    .content-big h4 {
        font-size: 22px;
        color: #ee2737;
        margin-bottom: 15px;
        font-weight: 700;
    }

    .content-big p {
        font-size: 16px;
        color: #000;
        text-align: justify;
        line-height: 1.7;
    }
</style>

<section class="page-banner">
    <div class="banner-content">
        <div class="container">
            <div class="row gy-4 align-items-center">
                <div class="col-lg-6">
                    <span class="banner-title">Education Loan <br> @ 0% Intrest EMI</span>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Education Loan @ 0% Intrest EMI</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-lg-6">
                    <div class="img-box">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/page-banner-img1.webp" alt="Institute of Chartered Financial Analyst">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




<section class="online-coaching">
    <div class="container">

        <div class="">
            <div class="row gy-4 align-items-center">
                <div class="col-lg-6">
                    <h6 class="coaching-subtitle">FREE CLASSES AND EDUCATION LOAN</h6>
                    <h5 class="coaching-title">FREE CLASSES</h5>
                    <p class="coaching-text">Ara Education supports students with FREE COACHING SCHEME.ARA
                        Education’s
                        free
                        classes is targeted towards providing
                        coaching of quality education for economically disadvantaged really needy students to enable
                        them to
                        appear in Indian &
                        International Professional examination to help budding professional course aspirants pursue
                        their
                        dreams & to empower
                        the youngsters to cherish in life .ARA Education helps to succeed in obtaining an
                        appropriate
                        job in
                        Big fortune
                        companies all over the world.</p>
                        <p class="common"><a href="{{ route('terms_and_conditions') }}" class="common">* Terms and Conditions applied</a></p>
                </div>
                <div class="col-lg-6">
                    <img class="wi-100" src="<?php echo url(''); ?>/public/frontend/assets/images/webimages/55.webp" alt="CA CS CMA Offline Classroom Live Coaching Programs">
                </div>
            </div>
            <div class="row gy-4 align-items-center mt-4">
                <div class="col-lg-6">
                    <h5 class="coaching-title">ELIGIBILTY FOR FREE CLASSES:</h5>
                    <ul class="coaching-list">
                        <li>Candidates who lost their parents due to some uncertainities.</li>
                        <li>Candidates who are goverened by guardians.</li>
                        <li>Candidates with low background whose annual income of parents is low.</li>
                        <li>Candidates with disablement</li>
                    </ul>
                    <p class="common"><a href="{{ route('terms_and_conditions') }}" class="common">* Terms and Conditions applied</a></p>
                </div>
                <div class="col-lg-6">
                    <p class="coaching-text"><b class="common">ARAians</b> can claim for Free Classes for the below
                        listed courses.</p>
                    <table class="table table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th>INDIAN COURSES</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>CS,CSEET</td>
                            </tr>
                            <tr>
                                <td>CA</td>
                            </tr>
                            <tr>
                                <td>CMA ICWA</td>
                            </tr>
                            <tr>
                                <td>CLAT</td>
                            </tr>
                            <tr>
                                <td>LAW ENTRANCE EXAM</td>
                            </tr>
                        </tbody>
                    </table>
                    
                </div>
            </div>
            <p class="coaching-text"><u>ARA AMBASSADOR TALENT SEARCH SCHOLARSHIP EXAM</u></p>
            <p class="coaching-text"><u>ARA EDUCATION’S PRESTIGIOUS ARA AMBASSADOR TALENT SEARCH SCHOLARSHIP SCHEME
                    FOR ARAIANS</u></p>
            <p class="coaching-text"><u>PAY LESS FEES,EARN ASSURED SCHOLARSHIP</u></p>
            <p class="coaching-text">Head in the right track on your preparation to all Indian & International
                Professional courses by securing 50- 100
                percent scholarship. Test your preparation on Professional Aptitude grade questions, at Commerce &
                Management National
                level.</p>
            <p class="coaching-text">PAY LESS FEES,EARN ASSURED SCHOLARSHIP Head in the right track on your
                preparation to all Indian & International
                Professional courses by securing 50- 100 percent scholarship. Test your preparation on Professional
                Aptitude grade
                questions, at Commerce & Management National level.</p>
            <p class="coaching-text"><b class="common">Ara Education’s</b> Meritorious ARA AMBASSADOR TALENT SEARCH
                SCHOLARSHIP EXAM
                rewards outstanding academic performance of
                talented candidates. The objective of the scheme is to provide top world class education with
                assistance to the
                meritorious students
                <b class="common">ARA Educational Institute</b> awards prizes, merit scholarships and
                merit-cum-means assistance to the
                meritorious students
                based on their performance who secured high score on the exam performance. It is a honour of ARAians
                availing 50-100%
                fee waiver for outstanding performance at national level.
            </p>
            <p class="coaching-text text-center"><b>ARAian's can claim Scholarship for the below listed courses
                    through writing
                    ARA
                    AMBASSADOR TALENT SEARCH SCHOLARSHIP EXAM</b>
                .</p>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th>INDIAN COURSES</th>
                            <th>INTERNATIONAL COURSES</th>
                            <th>DUAL INTEGRATED COURSES</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>CS,CSEET</td>
                            <td> ACCA</td>
                            <td> B.COM | BBA with CS</td>
                        </tr>
                        <tr>
                            <td>CA</td>
                            <td> USCMA</td>
                            <td>B.COM | BBA with CA</td>
                        </tr>
                        <tr>
                            <td>CMA ICWA</td>
                            <td> IFRS</td>
                            <td> B.COM | BBA with CMA</td>
                        </tr>
                        <tr>
                            <td>CLAT</td>
                            <td> FRM</td>
                            <td> B.COM | BBA | M.COM | MBA with ACCA</td>
                        </tr>
                        <tr>
                            <td>LAW ENTRANCE EXAM</td>
                            <td> CFA</td>
                            <td> B.COM | BBA | M.COM | MBA with USCMA</td>
                        </tr>
                        <tr>
                            <td>JUDICIARY EXAM</td>
                            <td> CPA</td>
                            <td> B.COM | BBA | M.COM | MBA with CIMA</td>
                        </tr>
                        <tr>
                            <td>LAW SUBJECT COACHING</td>
                            <td> EA</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>AT AUS</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>CMA AUS</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>CPA AUS</td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="row gy-4 align-items-center">
                <div class="col-lg-6">
                    <h5 class="coaching-title">ELIGIBILTY FOR SCHOLARSHIP SCHEME:</h5>
                    <ul class="coaching-list">
                        <li>10th completed candidates</li>
                        <li>+1 Pursuing Candidates</li>
                        <li>+1 Completed Candidates</li>
                        <li>+2 Pursuing Candidates</li>
                        <li>+2 Completed Candidates</li>
                        <li>UG Degree Pursuing Candidates</li>
                        <li>UG Degree Completed Candidates</li>
                        <li>PG Degree Pursuing Candidatess</li>
                        <li>PG Degree Completed Candidates</li>
                    </ul>
                     <p class="common mt-4"><a href="{{ route('terms_and_conditions') }}" class="common">* Terms and Conditions applied</a></p>
                </div>
                <div class="col-lg-6">
                   <img class="wi-100" src="<?php echo url(''); ?>/public/frontend/assets/images/webimages/56.webp" alt="ARA Education Scholarship">
                </div>
            </div>
            <div class="mt-4">
                <h5 class="coaching-title">EDUCATION LOAN WITH NO INTERST
                </h5>
                <p class="coaching-text"><b class="common">ARA EDUCATION</b> is delighted to introduce our Interest
                    Free Education Fees
                    Funding model.</p>
                <p class="coaching-text"><b class="common">Ara Education</b> as a Educational peer helps
                    parents|students to pay their education fees in monthly installments that too
                    at Zero interest and Zero cost.</p>
                <p class="coaching-text"><b class="common">Ara Education</b> assure you of Highest Approval Rate,
                    Quickest TAT & Easiest
                    Process with Seamless Service Support.</p>
                     <p class="common mt-2"><a href="{{ route('terms_and_conditions') }}" class="common">* Terms and Conditions applied</a></p>
            </div>
            <div class="row gy-4 align-items-center">
                <div class="col-lg-6">
                    <h5 class="coaching-title">BENEFITS TO THE STUDENTS</h5>
                    <ul class="coaching-list">
                        <li>Entire fees will be paid to the course upfront for the entire session in single go
                            without any hurdles student can
                            continue their education.</li>
                        <li>No security | collateral required from Students.</li>
                        <li>It Covers all payments - such as Admission fees, Registration fees, Hostel fee,
                            Transportation fee etc.</li>
                        <li>Support of Endless Education On uncertainties</li>
                        <li>Hassle free on usage of gadgets & widgets for Studies Apple | Samsung devices at "Zero
                            cost EMIs"</li>
                    </ul>
                     <p class="common"><a href="{{ route('terms_and_conditions') }}" class="common">* Terms and Conditions applied</a></p>
                </div>
                <div class="col-lg-6">
                    <img class="wi-100" src="<?php echo url(''); ?>/public/frontend/assets/images/webimages/58.webp" alt="Online CMA Coaching">
                </div>
            </div>
            <div class="row gy-4 align-items-center">
                <div class="col-lg-6 order-1 order-lg-0">
                   <img class="wi-100" src="<?php echo url(''); ?>/public/frontend/assets/images/webimages/59.webp" alt="JUDICIARY EXAM Coaching">
                </div>
                <div class="col-lg-6 order-0 order-lg-1">
                    <h5 class="coaching-title">BENEFITS TO PARENTS</h5>
                    <ul class="coaching-list">
                        <li>Free Insurance cover in case of Unfortunate Incident to Borrower.</li>
                        <li>Free Insurance cover (upto 3 EMIs | 25K) in case of Involuntary Job Loss to Borrower.
                        </li>
                        <li>Rewards | Cashback for Timely Repayment.</li>
                        <li>Provides Stress free payment hassle.</li>
                    </ul>
                     <p class="common"><a href="{{ route('terms_and_conditions') }}" class="common">* Terms and Conditions applied</a></p>
                </div>

            </div>
        </div>
    </div>
</section>



@include('frontend.newsletter')


@endsection