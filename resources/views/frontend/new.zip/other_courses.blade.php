@extends('frontend.layout.app')
@section('title', "CS ACS CA CMA  Institute Coimbatore ACCA USCMA CLAT Coaching center Tamilnadu - ARA Education" )
@section('description', "Coimbatore’s best Coaching Institute for CA CS ACS CSEET CMA ICWA academy  is ARA Education. Tamilnadu’s No1 Coaching Center for  ACCA USCMA CLAT training India" )
@section('keyword', "ca institute in Coimbatore ara education,best institute for ca
coaching ara education,Best ca coaching institute in Coimbatore tamilnadu ara education,Best chartered
accountant coaching in Coimbatore tamilnadu ara education,ca coaching institutecseet-clat ara education,CA
coaching institute in coimabtore ara education,Top institute for ca coaching classes in Coimbatore ara
education, Top CA coaching institute in Coimbatore tamilnadu ara education,Top ACA coaching
institutes in Coimbatore tamilnadu ara education,Top chartered accountant coaching institute in
tamilnadu coimbatore india ara education,ca coaching institute nearby,CA coaching institute in
Coimbatore tamilnadu ara education,ACA coaching institute in Coimbatore tamilnadu ara
education,Chartered Accountant institute in Coimbatore tamilnadu ara education,cs institute in Coimbatore ara education,best institute for cs
coaching ara education,Best cs coaching institute in Coimbatore tamilnadu ara education,Best company
secretary coaching in Coimbatore tamilnadu ara education,cs coaching institute ara education,CS
coaching institute in coimabtore ara education,Top institute for cs coaching classes in Coimbatore ara
education, Top CS coaching institutes in Coimbatore tamilnadu ara education,Top ACS coaching
institutes in Coimbatore tamilnadu ara education,Top company secretary coaching institute in tamilnadu
coimbatore india ara education,cs coaching institute nearby,CS coaching institute in Coimbatore
tamilnadu ara education,ACS coaching institute in Coimbatore tamilnadu ara education,Company
secretary institute in Coimbatore tamilnadu ara education,Company secretary institute ara
education,top cseet coaching institute in tamilnadu india ara education,cma institute in Coimbatore ara education,best institute for cma-
icwa coaching ara education,Best cma-icwa coaching institute in Coimbatore tamilnadu ara
education,Best cost and management accountant coaching in Coimbatore tamilnadu ara education,cma
coaching institute ara education,Cma-ICWA coaching institute in coimabtore ara education,Top institute
for cma-icwa coaching classes in Coimbatore ara education, Top CMA coaching institute in Coimbatore
tamilnadu ara education,Top ACMA coaching institutes in Coimbatore tamilnadu ara education,Top cost
and management accountant coaching institute in tamilnadu coimbatore india ara education,cma
coaching institute nearby,CMA coaching institute in Coimbatore tamilnadu ara education,ACMA
coaching institute in Coimbatore tamilnadu ara education,Cost and Management Accountant institute in
Coimbatore tamilnadu ara education,Cost and Management Accountant institute ara education,top
CMA foundation coaching institute in tamilnadu india ara education,CMA foundation Coaching institute
in Coimbatore ara education,top CMA Foundation coaching institute in tamilnadu india ara
education,CMA Foundation Coaching institute in Coimbatore ara education,ACCA coaching in center in coimbatore ara
education,ACCA Coaching classes in coimbatore ara education Tamilnadu India,ACCA
Coaching Institute in coimbatore Tamilnadu,ACCA Skill Coaching classes in coimbatore,Acca
knowledge level Coaching in coimbatore Tamilnadu,ACCA Professional Coaching Classes in
Coimbatore, Online ACCA Coaching Classes in coimbatore,online ACCA Knowledge coaching
classes in coimbatore, ACCA F1 coaching classes in coimbatore tamilnadu India,ACCA F2
coaching classes in coimbatore tamilnadu,ACCA F3 Coaching Classes in coimbatore Tamilnadu
india,ACCA F4 Coaching classes in coimbatore Tamilnadu India,ACCA F5 Coaching classes in
coimbatore,ACCA F6 Coaching classes in coimbatore,ACCA F7 coaching classes in coimbatore
Tamilnadu,ACCA F8 Coaching classes in coimbatore,ACCA F9 coaching Classes in
coimbatore,ACCA P1 coaching classes in coimbatore Tamilnadu,ACCA P2 coaching classes in
coimbatore,ACCA P3 Caoching classes in coimbatore Tamilnadu India, Acca P4 Coaching
Classes in coimbatore, ACCA P5 Coaching calsses in coimbatore tamilandu ARA Education,
Acca P6 Coaching Classes in coimabtore ara education. Acca tutions coimbatore ara education,
Acca Training online, Acca training coimbatore Ara Education ,US CMA coaching in center in coimbatore ara education, CMA USA
Coaching classes in coimbatore ara education Tamilnadu India, USCMA Online Coaching Institute in
coimbatore Tamilnadu ara education,USCMA Part-1 Coaching classes in coimbatore ara education,
USCMA Part -11 Coaching in coimbatore ara educationTamilnadu,CMA USA Coaching Classes in
Coimbatore ara education, Online cma usa Coaching Classes in coimbatore ara education
tamilnadu,online USCMA training in ara education coimbatore tamilnadu India, US CMA coaching classes
near me in coimbatore tamilnadu India,CMA USA coaching classes near me, IMA USCMA Coaching
Classes in coimbatore Tamilnadu india, US CMA Coaching Academy in coimbatore Tamilnadu ara
education India, USCMA Institute in coimbatore ara education,CMA US Institute Coaching classes in
coimbatore,Online IMA USCMA coaching classes in coimbatore Tamilnadu ara education,ARA Education
USCMA coaching Coaching classes in coimbatore,what after 12th, USCMA after 12th, USCMA near me
coaching classes in coimbatore Tamilnadu,online cma us coaching classes in coimbatore ARA Education,
uscma India Coaching classes in coimbatore Tamilnadu India ,IFRS coaching in center in coimbatore ara education, IFRS-
International certification course in coimbatore ara education Tamilnadu India, IFRS Online Coaching
Institute in coimbatore Tamilnadu ara education,CERT IFRS Coaching classes in coimbatore ara
education,DIP IFRS Coaching in coimbatore ara educationTamilnadu,IFRS coaching Classes in Coimbatore
ara education, Online IFRS Coaching Classes in coimbatore ara education tamilnadu,online IFRS training
in ara education coimbatore tamilnadu India, IFRS coaching classes near me in coimbatore tamilnadu
India, DIP IFRS coaching classes near me, ACCA IFRS- Coaching Classes in coimbatore Tamilnadu india,
IFRS Coaching Academy ara education in coimbatore Tamilnadu ara education India, IFRS Institute in
coimbatore ara education, IFRS UK Institute Coaching classes in coimbatore" )
@section('content')


<section class="page-banner">
    <div class="banner-content">
        <div class="container">
            <div class="row gy-4 align-items-center">
                <div class="col-lg-6">
                <span class="banner-title">Other Courses</span>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Other Courses</li>
                </ol>
            </nav>
                </div>
                <div class="col-lg-6">
                    <div class="img-box">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/page-banner-img1.webp" alt="ARA Law Academy is the best coaching for CLAT">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<section class="integrated-course-inner">
    <div class="container">
        <h5 class="course-title">UGC Recognized Online Degree Programs in collaboration with Top Ranking
            University
            in India</h5>

        <p class="course-text ">The Bachelor of Commerce is a three-year Degree Program that will prepare
            you for
            entry-level roles in both accounting
            and finance
        </p>
        <div class="row gy-4 align-items-center">
            <div class="col-lg-7">

                <p class="course-title-1">B.COM</p>
                <p class="course-text"><b class="common">Duration: </b>
                    3 Years
                </p>
                <p class="course-text"><b class="common">Program Commencement Month: </b>
                    July 31, 2021
                </p>
                <p class="course-text"><b class="common">Specializations Offered: </b>
                </p>
                <ul class="integrated-list">
                    <li>International Finance</li>
                    <li>Data Science and Analytics</li>
                    <li>Marketing</li>
                    <li>Finance</li>
                    <li>Human Resource Management</li>
                    <li>Digital Marketing</li>
                    <li>Real Estate management</li>
                    <li>Banking and Finance</li>
                </ul>
                <p class="course-text"><b class="common">Eligibility: </b>
                </p>
                <ul class="integrated-list">
                    <li>XII in Science | Commerce | Arts from PUC | ISC | CBSE or equivalent board.</li>
                    <li>Students who are due to appear in the board exams are also eligible to apply.
                        This program with a myriad of specializations will provide you with a strong foundation that
                        you
                        will need to pursue a
                        career in Finance, Accounting, and Management. The program curriculum encompasses courses of
                        professional accreditation
                        bodies from across the globe like ACCA, CIMA, CPA and CMA to give you that edge required to
                        compete
                        and succeed.</li>
                </ul>
            </div>
            <div class="col-lg-5">
                <div class="course-vector-img">
                    <img src="<?php echo url(''); ?>/public/frontend/assets/images/integrated-course/bcom_cs.png" alt="">
                </div>
            </div>
        </div>
        <div class="mt-5">
            <div class="row gy-4 align-items-center">
                <div class="col-lg-7">

                    <p class="course-title-1">BBA</p>
                    <p class="course-text"><b class="common">Duration: </b>
                        3 Years
                    </p>
                    <p class="course-text"><b class="common">Program Commencement Month: </b>
                        July 31, 2021
                    </p>
                    <p class="course-text"><b class="common">Specializations Offered: </b>
                    </p>
                    <ul class="integrated-list">
                        <li>International Finance</li>
                        <li>Data Science and Analytics</li>
                        <li>Marketing</li>
                        <li>Finance</li>
                        <li>Human Resource Management</li>
                        <li>Digital Marketing</li>
                        <li>Real Estate management</li>
                        <li>Banking and Finance</li>
                    </ul>
                    <p class="course-text"><b class="common">Eligibility: </b>
                    </p>
                    <ul class="integrated-list">
                        <li> XII in Science | Commerce | Arts from PUC | ISC | CBSE or equivalent board.
                        </li>
                        <li>Students who are due to appear in the board exams are also eligible to apply.</li>
                    </ul>
                </div>
                <div class="col-lg-5">
                    <div class="course-vector-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/integrated-course/best_cma.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="mt-5">
            <div class="row gy-4 align-items-center">
                <div class="col-lg-7">

                    <p class="course-title-1">MBA</p>
                    <p class="course-text"><b class="common">Duration: </b>
                        2 Years
                    </p>
                    <p class="course-text"><b class="common">Program Commencement Month: </b>
                        July 31, 2021
                    </p>
                    <p class="course-text"><b class="common">Specializations Offered: </b>
                    </p>
                    <ul class="integrated-list">
                        <li>Systems & Operations</li>
                        <li>Real Estate Management</li>
                        <li>Strategic Finance</li>
                        <li>Finance</li>
                        <li>Marketing</li>
                        <li>General management</li>
                        <li>Marketing and HRM</li>
                        <li>Marketing and finance</li>
                        <li>International finance</li>
                        <li>IT management</li>
                        <li>Finance and HRM</li>
                        <li>Analytics and data science</li>
                        <li>Investment Banking and Equity Research</li>
                        <li>Fintech</li>
                        <li>Banking and Finance</li>
                        <li>Digital Marketing and Ecommerce</li>
                        <li>Aviation Specialization</li>
                        <li>Structured Finance</li>
                        <li>Specialization</li>
                        <li>Logistics and Supply Chain Management</li>
                        <li>Wealth Management & Financial Planning Specialization</li>
                    </ul>
                    <p class="course-text"><b class="common">Eligibility: </b>
                    </p>
                    <ul class="integrated-list">
                        <li> Bachelor's Degree (Minimum of 3 Years Degree Program), with at least 50% marks or
                            equivalent CGPA (45% in case of SC|ST
                            ) from a recognized University.
                        </li>
                        <li>Students who are in the final year of the bachelor’s degree are also eligible to apply.
                        </li>
                    </ul>
                </div>
                <div class="col-lg-5">
                    <div class="course-vector-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/integrated-course/best_cma.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="mt-5">
            <div class="row gy-4 align-items-center">
                <div class="col-lg-7">

                    <p class="course-title-1">MCA</p>
                    <p class="course-text"><b class="common">Duration: </b>
                        2 Years
                    </p>
                    <p class="course-text"><b class="common">Program Commencement Month: </b>
                        July 31, 2021
                    </p>
                    <p class="course-text"><b class="common">Specializations Offered: </b>
                    </p>
                    <ul class="integrated-list">
                        <li>Computer Science & IT</li>
                        <li>Cyber Security (Integrated with CIIS,UK)</li>
                        <li>Data Analytics (Integrated with IOA, UK)</li>
                        <li>Full Stack Development</li>
                        <li>Cloud Computing</li>
                        <li>Data Science</li>
                        <li>Artificial Intelligence</li>
                    </ul>
                    <p class="course-text"><b class="common">Eligibility: </b>
                    </p>
                    <ul class="integrated-list">
                        <li>Bachelor's Degree (Minimum of 3 Years Degree Program), with at least 50% marks or
                            equivalent CGPA (45% in case of SC|ST
                            ) from a recognized University.
                        </li>
                        <li>The candidate must have passed Mathematics at 10+2 level or Graduation level securing
                            50% marks.
                        </li>
                        <li>Students who are in the final year of the bachelor’s degree are also eligible to apply.
                        </li>
                    </ul>
                </div>
                <div class="col-lg-5">
                    <div class="course-vector-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/integrated-course/best_cma.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="mt-5">
            <div class="row gy-4 align-items-center">
                <div class="col-lg-7">

                    <p class="course-title-1">M.COM</p>
                    <p class="course-text"><b class="common">Duration: </b>
                        2 Years
                    </p>
                    <p class="course-text"><b class="common">Program Commencement Month: </b>
                        July 31, 2021
                    </p>
                    <p class="course-text"><b class="common">Specializations Offered: </b>
                    </p>
                    <ul class="integrated-list">
                        <li>Accounting and Finance
                        </li>
                        <li>International Finance (Intergated with ACCA, UK)</li>

                    </ul>
                    <p class="course-text"><b class="common">Eligibility: </b>
                    </p>
                    <ul class="integrated-list">
                        <li> Bachelor's Degree (Minimum of 3 Years Degree Program), with at least 50% marks or
                            equivalent CGPA (45% in case of SC|ST
                            ) from a recognized University.
                        </li>
                        <li>The candidate must have passed Mathematics at 10+2 level or Graduation level securing
                            50% marks.
                        </li>
                        <li>Students who are in the final year of the bachelor’s degree are also eligible to apply.
                        </li>
                    </ul>
                </div>
                <div class="col-lg-5">
                    <div class="course-vector-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/integrated-course/best_cma.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="mt-5">
            <div class="row gy-4 align-items-center">
                <div class="col-lg-7">

                    <p class="course-title-1">M.A.</p>
                    <p class="course-text"><b class="common">Duration: </b>
                        2 Years
                    </p>
                    <p class="course-text"><b class="common">Program Commencement Month: </b>
                        July 31, 2021
                    </p>
                    <p class="course-text"><b class="common">Specializations Offered: </b>
                    </p>
                    <ul class="integrated-list">
                        <li>Economics</li>
                        <li>Journalism & Mass Communication</li>
                        <li>English</li>
                        <li>Public Policy and Administration</li>
                    </ul>
                    <p class="course-text"><b class="common">Eligibility: </b>
                    </p>
                    <ul class="integrated-list">
                        <li>Bachelor’s Degree with Journalism| English (for respective course) as a major subject
                            from a recognized University with
                            a minimum of 50% of total marks obtained (45% for SC|ST) in the cognate/related subjects
                            in the entire Degree course.The
                            candidate must have passed Mathematics at 10+2 level or Graduation level securing 50%
                            marks.
                        </li>
                        <li>Students who are in the final year of the bachelor’s degree are also eligible to apply..
                        </li>
                    </ul>
                </div>
                <div class="col-lg-5">
                    <div class="course-vector-img">
                        <img src="<?php echo url(''); ?>/public/frontend/assets/images/integrated-course/best_cma.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


@endsection